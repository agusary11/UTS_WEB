<template>
  <div class="home">
    <Navbar/>
    <div class="container">
      <Hero/>

      <div class="row mt-4">
        <div class="col">
          <h2>best<strong>sembako</strong></h2>
        </div>
        <div class="col">
          <router-link to="/sembako" class="btn btn-success">lihat semua</router-link>
        </div>
      </div>



    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import Navbar from '@/components/Navbar.vue'
import Hero from '../components/Hero.vue'
 '@/components/Hero.vue'

export default {
  name: 'Home',
  components: {
    Navbar,
    Hero
  }
}
</script>
