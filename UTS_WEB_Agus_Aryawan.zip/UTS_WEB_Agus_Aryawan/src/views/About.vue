<template>
  <div class="about">
    <h1>lagi pebaikan</h1>
  </div>
</template>
