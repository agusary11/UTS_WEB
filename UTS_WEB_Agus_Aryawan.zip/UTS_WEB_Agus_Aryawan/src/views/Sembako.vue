<template>
<div>
    <Navbar />
    <h2>Daftar Sembako</h2>
</div>
</template>
<script>
// @ is an alias to /src
import Navbar from '@/components/Navbar.vue'

export default {
  name: 'Sembako',
  components: {
    Navbar
  }
}
<style>

</style>