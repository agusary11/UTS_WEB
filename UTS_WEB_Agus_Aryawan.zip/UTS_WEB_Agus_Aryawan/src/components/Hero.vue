<template>
  <div class="hero">
    <div class="d-none d-md-block">
      <div class="row mt-4">
        <div class="col-md-6">
          <div class="d-flex h-100">
            <div class="justify-content-center align-self-center">
              <h2><strong>Kebutuhan Pokok, </strong><br />in Your Gadget</h2>
              <p>
                Ayo Lengkapilah Kebutuhan Favorite Dapur Anda Hanya Di WAROENG
              </p>
              <button class="btn btn-lg btn-success">
                <b-icon-arrow-right></b-icon-arrow-right>Pesan
              </button>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <img src="../assets/image/hero.png.png" width="100%" />
        </div>
      </div>
    </div>

    <div class="d-sm-block d-md-none">
      <div class="row mt-4">
        <div class="col-md-6">
          <div class="d-flex h-100">
            <div class="justify-content-center align-self-center">
              <h2><strong>Kebutuhan Pokok, </strong><br />in Your Gadget</h2>
              <p>
                Ayo Lengkapilah Kebutuhan Favorite Dapur Anda Hanya Di WAROENG
              </p>
              <button class="btn btn-lg btn-success">
                <b-icon-arrow-right></b-icon-arrow-right>Pesan
              </button>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <img src="../assets/image/hero.png.png" width="100%" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Hero",
};
</script>

<style>
</style>